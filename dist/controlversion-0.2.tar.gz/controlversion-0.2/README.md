import ControlVersion as Ctrl

p = Ctrl.Controller(url_git,key)